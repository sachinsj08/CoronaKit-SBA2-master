package com.eval.coronakit.service;


import com.eval.coronakit.entity.User;

public interface UserService {

	public User getUserDetails(String username);
}
