package com.eval.coronakit.exception;

public class ProductException extends Exception{

	public ProductException(String errMsg) {
		super(errMsg);
		// TODO Auto-generated constructor stub
	}
	

}
